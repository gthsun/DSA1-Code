package queue;

public class EmptyQueueException extends Exception {

    EmptyQueueException(String message) {
        super(message);
    }
}
